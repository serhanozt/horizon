var mysql = require('mysql');
var redis = require("redis");
const redisHost = "ip-10-0-121-153.eu-west-1.compute.internal"
const redisPort = 7777


var dbConfig = {
    host: 'predictiveanalytics.cwxvzubmfq3d.eu-west-1.rds.amazonaws.com',
    user: 'predictive',
    password: 'predictive_1186_',
    database: 'predictive'
};

var client = redis.createClient({
    port: redisPort,
    host: redisHost
});

client.get('testkey', function(err, value) {
    context.succeed(value);
})


var connection = mysql.createConnection(dbConfig);



exports.handler = function(event, context) {
    var statement = "select * from session_score_stats"
    connection.query(statement,
        function(err, rows, rowFields) {
            console.log(rows)
            context.succeed(err);
        });

};