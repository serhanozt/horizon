var redis = require("redis");
const redisHost = "ip-10-0-121-153.eu-west-1.compute.internal" 
const redisPort = 7777


exports.handler = function (event, context) {

       var client = redis.createClient({
            port: redisPort,
            host: redisHost
        });
        
         client.get('testkey', function (err, value) {
           context.succeed(value);
         })
        
};